import type { SubscriberArgs, SubscriberConfig } from "@medusajs/framework"
import type { MedusaContainer } from "@medusajs/framework/types"
import { Modules } from "@medusajs/framework/utils"
import { PaymentEvents } from "@medusajs/utils"
import { FULFILLMENT_ORDERS_MODULE } from "../modules/fulfillment-orders"
import type FulfillmentOrdersModuleService from "../modules/fulfillment-orders/service"
import { markOrderPaidAndFulfillmentWaiting } from "../lib/sync-order-paid-fulfillment"
import { tryRegisterWebhookDedupe } from "../lib/webhook-dedupe"
import { pushOrderToS2bdiy } from "../lib/s2bdiy/push-s2b-order"
import { getS2bdiyConfig } from "../modules/suppliers/s2bdiy/config"
import { STORE_CORE_MODULE } from "../modules/store-core"
import type StoreCoreModuleService from "../modules/store-core/service"
import { readOrderStoreId } from "../lib/order-store-context"
import { notifyFulfillmentFailed, notifyOrderPaid } from "../lib/notifications"
import { sendOrderConfirmation } from "../lib/email"

async function resolveOrderIdFromPayment(
  container: MedusaContainer,
  paymentId: string
): Promise<string | null> {
  const paymentModule = container.resolve(Modules.PAYMENT) as {
    retrievePayment: (
      id: string,
      config?: { relations?: string[] }
    ) => Promise<{ payment_collection_id?: string | null }>
  }
  const payment = await paymentModule.retrievePayment(paymentId, {
    relations: ["payment_collection"],
  })
  const pcId = payment.payment_collection_id
  if (!pcId) {
    return null
  }
  const foService = container.resolve(FULFILLMENT_ORDERS_MODULE) as FulfillmentOrdersModuleService
  const rows = await foService.listFulfillmentOrders({ payment_collection_id: [pcId] })
  return rows[0]?.order_id ?? null
}

export default async function paymentCapturedSyncHandler({
  event: { data },
  container,
}: SubscriberArgs<{ id: string }>) {
  const orderId = await resolveOrderIdFromPayment(container, data.id)
  if (!orderId) {
    return
  }

  const dedupeKey = `payment.captured:${data.id}`
  const firstTime = await tryRegisterWebhookDedupe(container, dedupeKey, "payment.captured")
  if (!firstTime) {
    return
  }

  await markOrderPaidAndFulfillmentWaiting(container, orderId, "payment.captured_event")

  try {
    const orderModule = container.resolve(Modules.ORDER)
    const order = await orderModule.retrieveOrder(orderId)
    const storeId = readOrderStoreId(order)
    if (storeId) {
      const storeCore = container.resolve(STORE_CORE_MODULE) as StoreCoreModuleService
      await notifyOrderPaid(storeCore, storeId, {
        orderId,
        displayId: typeof order.display_id === "number" ? order.display_id : null,
        email: typeof order.email === "string" ? order.email : null,
      })
    }

    if (typeof order.email === "string" && order.email.includes("@")) {
      const items = (order.items ?? []).map((item) => {
        const i = item as unknown as Record<string, unknown>
        return {
          title: String(i.title ?? "Item"),
          quantity: Number(i.quantity ?? 1),
          price: Number(i.unit_price ?? i.total ?? 0),
        }
      })
      await sendOrderConfirmation({
        to: order.email,
        orderId,
        displayId: typeof order.display_id === "number" ? order.display_id : null,
        items,
        total: Number(order.total ?? 0),
        currency: typeof order.currency_code === "string" ? order.currency_code : "usd",
      })
    }
  } catch (error) {
    console.error("Failed to create order_paid notification:", error)
  }

  if (getS2bdiyConfig()) {
    try {
      await pushOrderToS2bdiy(container, orderId)
    } catch (error) {
      console.error("S2BDIY push order failed after payment.captured:", error)
      try {
        const orderModule = container.resolve(Modules.ORDER)
        const order = await orderModule.retrieveOrder(orderId)
        const storeId = readOrderStoreId(order)
        if (storeId) {
          const storeCore = container.resolve(STORE_CORE_MODULE) as StoreCoreModuleService
          await notifyFulfillmentFailed(storeCore, storeId, {
            orderId,
            reason: error instanceof Error ? error.message : "S2BDIY push failed",
          })
        }
      } catch (notifyError) {
        console.error("Failed to create fulfillment_failed notification:", notifyError)
      }
    }
  }
}

export const config: SubscriberConfig = {
  event: PaymentEvents.CAPTURED,
}
